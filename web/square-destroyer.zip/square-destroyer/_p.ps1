npm --silent run play sample-question.txt sample-answer.txt
