<script setup>
import GameBoard from './components/GameBoard.vue'
</script>

<template>
  <GameBoard />
</template>

<style scoped>
</style>
